package com.sample;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by kasun on 5/24/17.
 */
public class LiquorService {

    public List<String> Conversor_String(String expresion) {
        List<String> list = new ArrayList<String>();
        int ind = 0;
        String element;
        char symbol;
        do {
            if ((symbol = expresion.charAt(ind)) < 48 || (symbol = expresion.charAt(ind)) > 57) {
                list.add("" + symbol);
                ind++;
            } else {
                element = "";
                while (ind < expresion.length() && (symbol = expresion.charAt(ind)) >= 48 && (symbol = expresion.charAt(ind)) <= 57) {
                    element += symbol;
                    ind++;
                }
                list.add(element);
            }
        }while (ind < expresion.length());
        System.out.println(list);
        return list;


    }
    public String do_operation(){
        String pepe = new String();
        return pepe;
    }
    public boolean operador(String operator) {
        return (operator.equals("+")  ||operator.equals("/")
                || operator.equals("-") || operator.equals("+")
                || operator.equals("*") ||
                operator.equals("%"));
    }
}