package com.sample;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet(
        name = "selectliquorservlet",
        urlPatterns = "/SelectLiquor"
)
public class SelectLiquorServlet extends HttpServlet {



    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String liquorType = req.getParameter("oper");
        System.out.println(liquorType);
        LiquorService liquorService = new LiquorService();
        GFG prefix = new GFG();
        arbolcalc tree = new arbolcalc();
        tree.buildTree(prefix.infixToPrefix(liquorType));
        System.out.print("\nPrefix  : ");
        tree.prefix();
        System.out.print("\n\nInfix   : ");
        tree.infix();
        System.out.print("\n\nPostfix : ");
        tree.postfix();
        System.out.println("\n\nEvaluated Result : "+ tree.evaluate());
        String[] liquorBrands = new String[2];
        liquorBrands[0] = liquorType;
        liquorBrands[1] = String.valueOf(tree.evaluate());
        System.out.println(liquorBrands[0]);
        System.out.println(liquorBrands[1]);
        hacecsv Historial = new hacecsv();
        Historial.writeFiles(0,liquorBrands[0],liquorBrands[1]);

        req.setAttribute("brands", liquorBrands);
        RequestDispatcher view = req.getRequestDispatcher("result.jsp");
        view.forward(req, resp);

    }
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");

        // Hello
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>" + "a" + "</h1>");
        out.println("</body></html>");
    }
}